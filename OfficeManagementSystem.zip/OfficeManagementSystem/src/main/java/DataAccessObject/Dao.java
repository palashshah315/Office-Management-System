package DataAccessObject;
import Employee.*;
import WorkSchedule.*;
import java.sql.*;
import java.util.*;
public class Dao {
	public  int Insert(Empbean emp) {
		int status = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("insert into `office_info`.`user` (`name`,`email`,`mobile`,`dob`,`username`,`password`,`address`,`pincode`,`type`) values (?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1,emp.getName());
			pstmt.setString(2,emp.getEmail());
			pstmt.setString(3,emp.getMobile());
			pstmt.setString(4, emp.getDob());
			pstmt.setString(5,emp.getUsername());
			pstmt.setString(6, emp.getPassword());
			pstmt.setString(7,emp.getAddress());
			pstmt.setString(8,emp.getPincode());
			pstmt.setString(9, emp.getType());
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return status;
	}
	public  int UpdateEmployee(Empbean emp) {
		int status = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("update `office_info`.`user` set `id`=?,`name`=?,`email`=?,`mobile`=?,`dob`=?,`username`=?,`password`=?,`address`=?,`pincode`=? where `id`=?");
			pstmt.setInt(1,emp.getId());
			pstmt.setString(2,emp.getName());
			pstmt.setString(3,emp.getEmail());
			pstmt.setString(4,emp.getMobile());
			pstmt.setString(5,emp.getDob());
			pstmt.setString(6, emp.getUsername());
			pstmt.setString(7,emp.getPassword());
			pstmt.setString(8,emp.getAddress());
			pstmt.setString(9,emp.getPincode());
			pstmt.setInt(10,emp.getId());
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
		}catch(Exception ex) {ex.printStackTrace();}
		return status;
	}
	public int UpdateAdmin(Empbean emp) {
		int status =0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("update `office_info`.`user` set `id`=?,`name`=?,`email`=?,`mobile`=?,`dob`=?,`username`=?,`password`=?,`address`=?,`pincode`=?,`type`=? where `id`=?");
			pstmt.setInt(1,emp.getId());
			pstmt.setString(2,emp.getName());
			pstmt.setString(3,emp.getEmail());
			pstmt.setString(4,emp.getMobile());
			pstmt.setString(5,emp.getDob());
			pstmt.setString(6, emp.getUsername());
			pstmt.setString(7,emp.getPassword());
			pstmt.setString(8,emp.getAddress());
			pstmt.setString(9,emp.getPincode());
			pstmt.setString(10,emp.getType());
			pstmt.setInt(11,emp.getId());
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
		}catch(Exception ex) {ex.printStackTrace();}
		return status;
	}
	public boolean checkUserLoginInfo(String login,String pwd) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select `user`.`username`,`user`.`password` from `office_info`.`user` where `user`.`username`=? and `user`.`password`=?");
			pstmt.setString(1, login);
			pstmt.setString(2,pwd);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				flag = true;
			}
			pstmt.close();
			rs.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return flag;
	}
	public int deleteUserByLoginidAndPassword(String login,String pwd) {
		int status = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("delete from `office_info`.`user` where `username`=? and `password`=?");
			pstmt.setString(1, login);
			pstmt.setString(2, pwd);
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		}catch(Exception e) {e.printStackTrace();}
		return status;
	}
	public  Empbean getUserbyLoginAndPwd(String login,String pwd) {
		Empbean e = new Empbean();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select * from `office_info`.`user` where `username`=? and `password`=?");
			pstmt.setString(1, login);
			pstmt.setString(2, pwd);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmail(rs.getString(3));
				e.setMobile(rs.getString(4));
				e.setDob(rs.getString(5));
				e.setUsername(rs.getString(6));
				e.setPassword(rs.getString(7));
				e.setAddress(rs.getString(8));
				e.setPincode(rs.getString(9));
				e.setType(rs.getString(10));
			}
			pstmt.close();
			rs.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return e;
	}
	public List<Empbean> getAllUser() {
		List<Empbean> list = new ArrayList<Empbean>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select * from `office_info`.`user`");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				Empbean e = new Empbean();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmail(rs.getString(3));
				e.setMobile(rs.getString(4));
				e.setDob(rs.getString(5));
				e.setUsername(rs.getString(6));
				e.setPassword(rs.getString(7));
				e.setAddress(rs.getString(8));
				e.setPincode(rs.getString(9));
				e.setType(rs.getString(10));
				list.add(e);
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return list;
	}
	
	public int InsertWork(BeanWork bw) {
		int status = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("insert into `office_info`.`work` (`user_id`,`file_no`,`client_name`,`client_no`,`land_type`,`land_no`,`Assignment`,`stamp_duty`,`registration_fee`,`remark`) values (?,?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1,	bw.getUserId());
			pstmt.setString(2, bw.getFileNo());
			pstmt.setString(3, bw.getClientName());
			pstmt.setString(4,bw.getClientMobile());
			pstmt.setString(5, bw.getLandType());
			pstmt.setString(6, bw.getLandNo());
			pstmt.setString(7, bw.getAssignment());
			pstmt.setString(8, bw.getStampDuty());
			pstmt.setString(9, bw.getRegFee());
			pstmt.setString(10, bw.getRemark());
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
		}catch(Exception ex) {ex.printStackTrace();}
		return status;
	}
	public List<BeanWork> getAllIdAndNameFromUser(){
		List<BeanWork> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select `user`.`id`,`user`.`name` from `office_info`.`user`");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				BeanWork bw = new BeanWork();
				bw.setUserId(rs.getInt(1));
				bw.setWorkAssigned(rs.getString(2));
				list.add(bw);
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return list;
	}
	public List<BeanWork> getAllUserWork(){
		List<BeanWork> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select `office_info`.`user`.name , `office_info`.`work`.* from `office_info`.`user` left join `office_info`.`work` on `office_info`.`user`.id = `office_info`.`work`.user_id");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				BeanWork b = new BeanWork();
				b.setWorkAssigned(rs.getString(1));
				b.setSerialNo(rs.getInt(2));
				b.setUserId(rs.getInt(3));
				b.setFileNo(rs.getString(4));
				b.setClientName(rs.getString(5));
				b.setClientMobile(rs.getString(6));
				b.setLandType(rs.getString(7));
				b.setLandNo(rs.getString(8));
				b.setAssignment(rs.getString(9));
				b.setStampDuty(rs.getString(10));
				b.setRegFee(rs.getString(11));
				b.setAppointDate(rs.getString(12));
				b.setTime(rs.getString(13));
				b.setSro(rs.getString(14));
				b.setRemark(rs.getString(15));
				b.setDocumentNo(rs.getString(16));
				b.setDate(rs.getString(17));
				b.setPde(rs.getString(18));
				list.add(b);
			}
			
		}catch(Exception ex) {ex.printStackTrace();}
		return list;
	}
	public List<BeanWork> getWorkById(int user_id){
		List<BeanWork> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select * from `office_info`.`work` where `user_id`=?");
			pstmt.setInt(1, user_id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				BeanWork b = new BeanWork();
			
				b.setSerialNo(rs.getInt(1));
				b.setUserId(rs.getInt(2));
				b.setFileNo(rs.getString(3));
				b.setClientName(rs.getString(4));
				b.setClientMobile(rs.getString(5));
				b.setLandType(rs.getString(6));
				b.setLandNo(rs.getString(7));
				b.setAssignment(rs.getString(8));
				b.setStampDuty(rs.getString(9));
				b.setRegFee(rs.getString(10));
				b.setAppointDate(rs.getString(11));
				b.setTime(rs.getString(12));
				b.setSro(rs.getString(13));
				b.setRemark(rs.getString(14));
				b.setDocumentNo(rs.getString(15));
				b.setDate(rs.getString(16));
				b.setPde(rs.getString(17));
				
				list.add(b);
			}
		}catch(Exception ex) {ex.printStackTrace();}
		return list;
	}
	public int UpdateWorkBySerialNo(BeanWork bw) {
		int status = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("update `office_info`.`work` set `sr`=?,`user_id`=?,`file_no`=?,`client_name`=?,`client_no`=?,`land_type`=?,`land_no`=?,`Assignment`=?,`stamp_duty`=?,`registration_fee`=?,`appointment_date`=?,`time`=?,`sro`=?,`remark`=?,`document_no`=?,`date`=?,`pde`=? where `sr`=?");
			pstmt.setInt(1, bw.getSerialNo());
			pstmt.setInt(2, bw.getUserId());
			pstmt.setString(3, bw.getFileNo());
			pstmt.setString(4, bw.getClientName());
			pstmt.setString(5, bw.getClientMobile());
			pstmt.setString(6, bw.getLandType());
			pstmt.setString(7, bw.getLandNo());
			pstmt.setString(8, bw.getAssignment());
			pstmt.setString(9, bw.getStampDuty());
			pstmt.setString(10, bw.getRegFee());
			pstmt.setString(11, bw.getAppointDate());
			pstmt.setString(12, bw.getTime());
			pstmt.setString(13, bw.getSro());
			pstmt.setString(14, bw.getRemark());
			pstmt.setString(15, bw.getDocumentNo());
			pstmt.setString(16, bw.getDate());
			pstmt.setString(17, bw.getPde());
			pstmt.setInt(18,bw.getSerialNo());
			
			status = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return status;
	}
	public Empbean getUserEmailById(int user_id) {
		Empbean e = new Empbean();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_info","root","root");
			PreparedStatement pstmt = con.prepareStatement("select `email` from `office_info`.`user` where `id`=?");
			pstmt.setInt(1, user_id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				e.setEmail(rs.getString(1));
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(Exception ex) {ex.printStackTrace();}
		return e;
	}
}
