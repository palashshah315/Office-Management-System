package WorkSchedule;
import DataAccessObject.*;
import java.io.*;
import java.util.*;
import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@WebServlet("/UpdateWork")
public class UpdateWork extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateWork() {
        super();
        
    }
//    private void SendEmail(String admin_email, String user_email, String pass, String file_no, String land_no,PrintWriter out) 
//    {
//    	Properties props = new Properties();
//    	props.put("mail.smtp.starttls.enable","true"); 
//    	props.put("mail.smtp.user",admin_email); 
//    	props.put("mail.smtp.host", "smtp.gmail.com");  
//    	props.put("mail.smtp.auth", "true"); 
//    	props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory"); 
//    	props.setProperty("mail.smtp.socketFactory.fallback", "false"); 
//    	props.setProperty("mail.smtp.port", "465"); 
//    	props.setProperty("mail.smtp.socketFactory.port", "465"); 
//
//    	
//    	Session ss = Session.getInstance(props,new Authenticator() {
//    		@Override
//    		protected PasswordAuthentication getPasswordAuthentication() {
//    			return new PasswordAuthentication(admin_email,pass);
//    			
//    		}
//    	});
//    	ss.setDebug(true);
//    	MimeMessage m = new MimeMessage(ss);
//    	try {
//    		m.setFrom(new InternetAddress(admin_email));
//    		m.addRecipient(Message.RecipientType.TO,new InternetAddress(user_email));
//    		m.setSubject("Regarding Your Work");
//    		
//    		m.setText("Your File Number is "+file_no+" And Survey No./Block No. is "+land_no);
//    		
//    		Transport.send(m);
//    		
//    		System.out.println("Mail sent Successfully....");
//
//    		
//    	}catch(Exception ex) {ex.printStackTrace();}
//    	
//    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String s = request.getParameter("sr_no");
		int sr_no = Integer.parseInt(s);
		String id = request.getParameter("user_id");
		int user_id = Integer.parseInt(id);
		String file_no = request.getParameter("file_no");
		String client_name = request.getParameter("client_name");
		String client_no = request.getParameter("client_no");
		String land_type = request.getParameter("land_type");
		String land_no = request.getParameter("land_no");
		String assignment = request.getParameter("assignment");
		String pde = request.getParameter("pde");
		String stamp_duty = request.getParameter("stamp_duty");
		String reg_fee = request.getParameter("reg_fee");
		String appt_date = request.getParameter("appointment_date");
		String time = request.getParameter("time");
		String sro = request.getParameter("sro");
		String remark = request.getParameter("remark");
		String doc_no = request.getParameter("document_no");
		String date = request.getParameter("date");
		
		PrintWriter out  = response.getWriter();
		BeanWork b = new BeanWork();
		Dao d = new Dao();
		if(sr_no!=0 && user_id!=0 && !file_no.isEmpty() && !client_name.isEmpty() && !client_no.isEmpty() && !land_type.isEmpty() && !land_no.isEmpty() && !assignment.isEmpty() && !stamp_duty.isEmpty() && !reg_fee.isEmpty() && !appt_date.isEmpty() && !time.isEmpty() && !sro.isEmpty() && !remark.isEmpty() && !doc_no.isEmpty() && !date.isEmpty() && !pde.isEmpty()) 
		{
			HttpSession ss = request.getSession();
			
			
			b.setSerialNo(sr_no);
			b.setUserId(user_id);
			b.setFileNo(file_no);
			b.setClientName(client_name);
			b.setClientMobile(client_no);
			b.setLandType(land_type);
			b.setLandNo(land_no);
			b.setAssignment(assignment);
			b.setStampDuty(stamp_duty);
			b.setRegFee(reg_fee);
			b.setAppointDate(appt_date);
			b.setTime(time);
			b.setSro(sro);
			b.setRemark(remark);
			b.setDocumentNo(doc_no);
			b.setDate(date);
			b.setPde(pde);
			
			
			ss.setAttribute("sr_no", sr_no);
			ss.setAttribute("user_id",user_id);
			ss.setAttribute("file_no",file_no);
			ss.setAttribute("client_name",client_name);
			ss.setAttribute("client_no",client_no);
			ss.setAttribute("land_type",land_type);
			ss.setAttribute("land_no",land_no);
			ss.setAttribute("assignment",assignment);
			ss.setAttribute("stmp_duty",stamp_duty);
			ss.setAttribute("registration_fee", reg_fee);
			ss.setAttribute("appt_date", appt_date);
			ss.setAttribute("time",time);
			ss.setAttribute("sro",sro);
			ss.setAttribute("remarked", remark);
			ss.setAttribute("doc_no", doc_no);
			ss.setAttribute("date", date);
			ss.setAttribute("pde", pde);
			
			int status = 0;
			status = d.UpdateWorkBySerialNo(b);
			//SendEmail("palashshah345@gmail.com","palashshah.18.it@iite.indusuni.ac.in","palash315",file_no,land_no,out);
			if(status > 0 ) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Your Work is Update Successfully');");
				out.println("</script>");
				out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
				
			}
		}
		else if(sr_no == 0) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Serial Number Can't be Zero');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(user_id == 0) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('User id Can't be Zero');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(file_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('File Number Can't be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(client_name.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Client Name Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(client_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Client Mobile Number Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(land_type.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Type Of Land Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(land_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Survey No. / Block No. Can't Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(assignment.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Your Assignment/Job/Task can't be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(pde.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('PDE Number Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(stamp_duty.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Stamp Duty Work Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(reg_fee.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Registration Fee Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(appt_date.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Appointment Date Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(time.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Time Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(sro.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Please Fill Up SRO');");
			out.println("</script>");
		}
		else if(remark.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Please Fill Up Remark');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(doc_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Document Number Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		else if(date.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Date Must Not Be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=ViewWork.jsp\">");
		}
		
		out.close();
	}
}