package WorkSchedule;
import DataAccessObject.*;
import Employee.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@WebServlet("/AssignedWork")
public class AssignedWork extends HttpServlet{
	private static final long serialVersionUID = 1L;
    public AssignedWork() {
        super();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int user_id = 0;
		String id = request.getParameter("user_id");
		user_id = Integer.parseInt(id);
		
		String file_no = request.getParameter("file_no");
		String client_name = request.getParameter("client_name");
		String client_mobile = request.getParameter("client_mobile");
		String land_type = request.getParameter("land_type");
		String land_no = request.getParameter("land_no");
		String assignment = request.getParameter("assignment");
		String stamp_duty = "Pending";
		String reg_fee = "Pending";
		String remark = "Pending";
		PrintWriter out = response.getWriter();
		
		
		if(!file_no.isEmpty() && !client_name.isEmpty() && !client_mobile.isEmpty() && !land_type.isEmpty() && !land_no.isEmpty() && !assignment.isEmpty()) 
		{
			
			
			Dao d = new Dao();
			
			BeanWork bw = new BeanWork();
			Empbean e = new Empbean();
			
			bw.setUserId(user_id);
			bw.setFileNo(file_no);
			bw.setClientName(client_name);
			bw.setClientMobile(client_mobile);
			bw.setLandType(land_type);
			bw.setLandNo(land_no);
			bw.setAssignment(assignment);
			bw.setStampDuty(stamp_duty);
			bw.setRegFee(reg_fee);
			bw.setRemark(remark);
			
			
			int status = d.InsertWork(bw);
			
			e = d.getUserEmailById(user_id);
			 
			String user_email = e.getEmail();
			 
			if(status > 0) {
				
				HttpSession session = request.getSession();
				session.setAttribute("user_id",user_id);
				session.setAttribute("file_no",file_no);
				session.setAttribute("client_name", client_name);
				session.setAttribute("client_mobile",client_mobile);
				session.setAttribute("assignment",assignment);
				session.setAttribute("land_type", land_type);
				session.setAttribute("land_no", land_no);
				session.setAttribute("stamp_duty",stamp_duty);
				session.setAttribute("reg_fee", reg_fee);
				session.setAttribute("remark",remark);
				session.setAttribute("user_email",user_email);
				
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Worked Assigned Successfully');");
				out.println("</script>");
				out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
				
				
			}
		}
		else if(user_id == 0) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Please Select Name To Work Assign');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(file_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('File Number must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(client_name.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Client Name must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(client_mobile.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Client Mobile Number must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(land_type.isEmpty() ) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Land Type must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(land_no.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Land Number must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		else if(assignment.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Your Assignment must not be Empty');");
			out.println("</script>");
			out.println("<meta http-equiv=\"Refresh\" content=\"0;url=AssignWork.jsp\">");
		}
		out.close();
	}

}
