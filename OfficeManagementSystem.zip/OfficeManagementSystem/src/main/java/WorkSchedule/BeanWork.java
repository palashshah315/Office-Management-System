package WorkSchedule;
 public class BeanWork {
public String work_assigned,file_no,client_name,client_mobile,land_type,land_no,assignment,stamp_duty,reg_fee,appointment_date,time,sro,remark,document_no,date,pde;
public int sr,id;
public void setSerialNo(int sr) {
	this.sr = sr;
	}
public int getSerialNo() {
	return sr;
	}
public void setWorkAssigned(String work_assign) {
	this.work_assigned = work_assign;
	}
public String getWorkAssigned() {
	return work_assigned;
	}
public void setFileNo(String file_no) {
	this.file_no = file_no;
	}
public String getFileNo() {
	return file_no;
	}
public void setClientName(String client_name) {
	this.client_name = client_name;
	}
public String getClientName() {
	return client_name;
	}
public void setClientMobile(String client_mobile) {
	this.client_mobile = client_mobile;
	}
public String getClientMobile() {
	return client_mobile;
	}
public void setLandType(String land_type) {
	this.land_type = land_type;
	}
public String getLandType() {
	return land_type;
	}
public void setLandNo(String land_no) {
	this.land_no = land_no;
	}
public String getLandNo() {
	return land_no;
	}
public void setAssignment(String assignment) {
	this.assignment = assignment;
	}
public String getAssignment() {
	return assignment;
	}
public void setStampDuty(String stamp_duty) {
	this.stamp_duty = stamp_duty;
	}
public String getStampDuty() {
	return stamp_duty;
	}
public void setRegFee(String reg_fee) {
	this.reg_fee = reg_fee;
	}
public String getRegFee() {
	return reg_fee;
	}
public void setAppointDate(String appointment_date) {
	this.appointment_date = appointment_date;
	}
public String getAppointDate() {
	return appointment_date;
	}
public void setTime(String time) {
	this.time = time;
	}
public String getTime() {
	return time;
	}
public void setSro(String sro) {
	this.sro = sro;
	}
public String getSro() {
	return sro;
	}
public void setRemark(String remark) {
	this.remark = remark;
	}
public String getRemark() {
	return remark;
	}
public void setDocumentNo(String document_no) {
	this.document_no = document_no;
	}
public String getDocumentNo() {
	return document_no;
	}
public void setDate(String date) {
	this.date = date;

	}
public String getDate() {
	return date;
	}
public void setPde(String pde) {
	this.pde = pde;
	}
public String getPde() {
	return pde;
	}
public void setUserId(int id) {
	this.id = id;
	
	}
public int getUserId() {
	return id;
	}
}
