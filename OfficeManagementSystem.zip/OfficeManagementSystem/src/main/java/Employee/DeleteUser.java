package Employee;
import DataAccessObject.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@WebServlet("/DeleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DeleteUser() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String loginId = request.getParameter("uname");
		String password = request.getParameter("pwd");
		PrintWriter out = response.getWriter();
		if(!loginId.isEmpty() && !password.isEmpty()) 
		{
			Dao d = new Dao();
			int status = d.deleteUserByLoginidAndPassword(loginId,password);
			if(status > 0) 
			{
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Record Deleted Successfully');");
				out.println("</script>");
				out.println("<meta http-equiv=\"Refresh\" content=\"0;url=index.html\">");
			}
		}
		else if(loginId.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Username must not be Empty');");
			out.println("</script>");
		}
		else if(password.isEmpty()) {
			out.println("<script type = \"text/javascript\">");
			out.println("alert('password must not be Empty');");
			out.println("</script>");
		}
	}

}
