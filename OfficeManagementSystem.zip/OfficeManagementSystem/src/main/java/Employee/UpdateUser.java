package Employee;
import DataAccessObject.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateUser() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
			PrintWriter out = response.getWriter();
		 	String userid = request.getParameter("e_id");
			int id = Integer.parseInt(userid);
			String name = request.getParameter("e_name");
			String email = request.getParameter("e_email");
			String mobile = request.getParameter("e_mobile");
			String dob = request.getParameter("e_dob");
			String username = request.getParameter("e_newusername");
			String pwd  =request.getParameter("e_newpswd");
			String address  =request.getParameter("e_address");
			String pincode = request.getParameter("e_pincode");
			String type = request.getParameter("e_type");
			Empbean e  = new Empbean();
			if(!name.isEmpty() && !email.isEmpty() && !mobile.isEmpty() && !address.isEmpty() && !dob.isEmpty() && !username.isEmpty() && !pwd.isEmpty() && !pincode.isEmpty() && !type.isEmpty())
			{
			e.setId(id);
			e.setName(name);
			e.setEmail(email);
			e.setMobile(mobile);
			e.setDob(dob);
			e.setUsername(username);
			e.setPassword(pwd);
			e.setAddress(address);
			e.setPincode(pincode);
			e.setType(type);
			Dao d = new Dao();
			
			if(type == "Admin") {
				int status = d.UpdateAdmin(e);
				if(status > 0){
					HttpSession ss = request.getSession();
					ss.setAttribute("id", id);
					ss.setAttribute("name", name);
					ss.setAttribute("email", email);
					ss.setAttribute("mobile",mobile);
					ss.setAttribute("dob", dob);
					ss.setAttribute("uname",username);
					ss.setAttribute("pswd", pwd);
					ss.setAttribute("address", address);
					ss.setAttribute("pincode", pincode);
					ss.setAttribute("type", type);
					response.sendRedirect("UpdatedUser.jsp");
					}
				}
			else {
				int status = d.UpdateEmployee(e);
				if(status > 0){
					HttpSession ss = request.getSession();
					ss.setAttribute("id", id);
					ss.setAttribute("name", name);
					ss.setAttribute("email", email);
					ss.setAttribute("mobile",mobile);
					ss.setAttribute("dob", dob);
					ss.setAttribute("uname",username);
					ss.setAttribute("pswd", pwd);
					ss.setAttribute("address", address);
					ss.setAttribute("pincode", pincode);
					ss.setAttribute("type", type);
					response.sendRedirect("UpdatedUser.jsp");
					}
				}
			}			
			else if(name.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('name must not be Empty');");
				out.println("</script>");
			}
			else if(email.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('email must not be Empty');");
				out.println("</script>");
			}
			else if(mobile.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Mobile Number must not be Empty');");
				out.println("</script>");
			}
			else if(dob.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Date of Birth must not be Empty');");
				out.println("</script>");
			}
			else if(username.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Username must not be Empty');");
				out.println("</script>");
			}
			else if(pwd.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Password must not be Empty');");
				out.println("</script>");
			}
			else if(address.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('Address must not be Empty');");
				out.println("</script>");
			}
			else if(pincode.isEmpty()) {
				out.println("<script type = \"text/javascript\">");
				out.println("alert('pincode  must not be Empty');");
				out.println("</script>");
			}
			else if(type.isEmpty()) {
				
				out.println("<script type = \"text/javascript\">");
				out.println("alert('User type must not be Empty');");
				out.println("</script>");
			
			}
	}

}
