package Employee;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import DataAccessObject.*;
@SuppressWarnings("serial")
@WebServlet("/EmployeeSignUp")
public class EmployeeSignUp extends HttpServlet {
    public EmployeeSignUp() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("e_name");
		String email = request.getParameter("e_email");
		String mobile = request.getParameter("e_mobile");
		String dob = request.getParameter("e_dob");
		String username = request.getParameter("e_newusername");
		String password = request.getParameter("e_newpswd");
		String address = request.getParameter("e_address");
		String pincode = request.getParameter("e_pincode");		
		String type = "Employee";
		
		Empbean emp = new Empbean();
	if(!name.isEmpty() && !email.isEmpty() && !mobile.isEmpty() && !address.isEmpty() && !dob.isEmpty() && !username.isEmpty() && !password.isEmpty() && !pincode.isEmpty())
	{
		emp.setName(name);
		emp.setEmail(email);
		emp.setMobile(mobile);
		emp.setDob(dob);
		emp.setUsername(username);
		emp.setPassword(password);
		emp.setAddress(address);
		emp.setPincode(pincode);
		emp.setType(type);	
		Dao d = new Dao();
		
        	int status = d.Insert(emp);
        	if(status>0) {
        		out.println("<script type = \"text/javascript\">");
        		out.println("alert('You Registered Successfully');");
        		out.println("</script>");	
        		out.println("<meta http-equiv=\"Refresh\" content=\"0;url=index.html\">");
        	}
     }
	else if(name.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('name must not be Empty');");
		out.println("</script>");
	}
	else if(email.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('email must not be Empty');");
		out.println("</script>");
	}
	else if(mobile.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('Mobile Number must not be Empty');");
		out.println("</script>");
	}
	else if(dob.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('Date of Birth must not be Empty');");
		out.println("</script>");
	}
	else if(username.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('Username must not be Empty');");
		out.println("</script>");
	}
	else if(password.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('Password must not be Empty');");
		out.println("</script>");
	}
	else if(address.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('Address must not be Empty');");
		out.println("</script>");
	}
	else if(pincode.isEmpty()) {
		out.println("<script type = \"text/javascript\">");
		out.println("alert('pincode  must not be Empty');");
		out.println("</script>");
	}
	else if(type.isEmpty()) {
		
		out.println("<script type = \"text/javascript\">");
		out.println("alert('User type must not be Empty');");
		out.println("</script>");
	
	}
		out.close();
	}

}
