package Employee;
public class Empbean {
	public int id;
	public String name,email,mobile,username,password,address,pincode,dob,type;
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {  
	    return id;  
	}  
	public void setName(String name) {
		
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setEmail(String email) {
		this.email=email;
	}
	public String getEmail() {  
	    return email;  
	}  
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMobile() {
		return mobile;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDob() {
		return dob;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setAddress(String address) {  
	    this.address = address;  
	} 
	public String getAddress() {  
	    return address;  
	} 
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getPincode() {
		return pincode;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
}
